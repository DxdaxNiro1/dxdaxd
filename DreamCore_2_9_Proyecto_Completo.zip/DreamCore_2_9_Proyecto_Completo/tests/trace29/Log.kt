package android.util
object Log {fun w(tag:String,message:String,e:Throwable)=0}
