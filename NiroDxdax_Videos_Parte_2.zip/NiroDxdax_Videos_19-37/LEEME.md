# NiroDxdax · DreamCore · Videos musicales

Este paquete contiene **19 videos MP4** y sus portadas con **NiroDxdax** como marca de agua visible. Cada video combina la portada ilustrada de su mapa con la canción completa correspondiente.

1. Descarga el ZIP y extrae todo su contenido.
2. Abre `VER_VIDEOS.html` para elegir una canción, o reproduce cualquier archivo de `Videos`.
3. Para YouTube, selecciona el MP4 al subir un video. Puedes usar el JPG de `Portadas` como miniatura.

Formato: 1920 × 1080, horizontal 16:9, 24 FPS, H.264 y AAC estéreo a 160 kb/s. Las imágenes permanecen fijas durante la canción. La resolución de exportación es 1080p; las portadas originales se adaptan sin recortar títulos. El álbum fue creado con asistencia de IA.

Cada ZIP es independiente y puede extraerse por separado. Los nombres de archivos son compatibles con Windows. `MANIFIESTO.json` identifica cada pareja y contiene las sumas SHA-256 de los MP4. Las portadas representan los mapas mediante ilustraciones; los videos no son grabaciones de una partida.

## Canciones incluidas

- 19. **La ropa de otra vida** — Lavandería entre nubes (2:16)
- 20. **El último vagón sumergido** — El tren bajo el agua (1:56)
- 21. **Las seis y nunca más** — El amanecer que no termina (2:12)
- 22. **El horizonte tenía una escalera** — La torre que viste desde lejos (1:52)
- 23. **El peso azul del sueño** — Una cama al borde del universo (2:08)
- 24. **También pusieron tu taza** — La habitación que te espera (2:00)
- 25. **La casa antes de tu llegada** — Fotografía: la casa sin nadie (2:24)
- 26. **Una marea detenida en papel** — Fotografía: el mar inmóvil (2:16)
- 27. **El cielo detrás del cristal** — Fotografía: las ventanas de ayer (1:56)
- 28. **Una órbita en el álbum** — Fotografía: el planeta detenido (2:12)
- 29. **Dirección: nadie, nunca** — La casa del destinatario ausente (1:52)
- 30. **El techo aprende tus pasos** — El suelo que se volvió cielo (2:08)
- 31. **Calles que se doblan al dormir** — El barrio que se inclinó (2:00)
- 32. **La película que mira la Tierra** — El cine sobre la Tierra (2:24)
- 33. **Duchas para un valle vacío** — Las duchas del valle infinito (2:16)
- 34. **El reflejo llegó primero** — La casa reflejada entre nubes (1:56)
- 35. **Los hongos sueñan bajo el canal** — El canal de los hongos dormidos (2:12)
- 36. **Una nube ocupa todo el día** — La colina de la nube inmensa (1:52)
- 37. **Nadie viene a repostar** — La última gasolinera del atardecer (2:08)
