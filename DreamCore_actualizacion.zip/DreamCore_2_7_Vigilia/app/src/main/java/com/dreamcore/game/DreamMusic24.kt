package com.dreamcore.game

/** One authored composition per world, plus the title. Metadata does not touch Android. */
object DreamMusic24 {
    const val TITLE="title"
    data class Track(val number:Int,val world:String,val title:String,val map:String,val description:String,val seconds:Int,val resource:String,val cover:String)
    val tracks=listOf(
        Track(1,"title","Antes de recordar","Inicio","piano de fieltro, cinta suave y acordes suspendidos",112,"music_score_01_24","music_cover_01_24"),
        Track(2,"dream_01","Cinco puertas al atardecer","El Umbral: Dreamcore y Dark Fantasy","cristal suave, resonancias y voces lejanas",128,"music_score_02_24","music_cover_02_24"),
        Track(3,"dream_02","El agua conserva las voces","Piscinas del recuerdo","piano acuoso, ecos asimétricos y armónicos líquidos",120,"music_score_03_24","music_cover_03_24"),
        Track(4,"dream_03","Casas que caen despacio","El abismo de las casas perdidas","cuerdas lentas, armónicos oscuros y campanas remotas",144,"music_score_04_24","music_cover_04_24"),
        Track(5,"dream_04","La lluvia olvidó el suelo","Los jardines de cristal dormido","arpa de nylon, aire y notas que quedan suspendidas",136,"music_score_05_24","music_cover_05_24"),
        Track(6,"dream_05","Alguien dejó la luz","El pueblo de las ventanas despiertas","piano de fieltro, cinta suave y acordes suspendidos",116,"music_score_06_24","music_cover_06_24"),
        Track(7,"dream_06","Mareas sobre las ventanas","El mar dentro del cielo","flauta de aire, graves aterciopelados y silencios amplios",132,"music_score_07_24","music_cover_07_24"),
        Track(8,"dream_07","La puerta del fondo respira","La casa que recuerda otra puerta","teclado de cinta, reversos y un pulso que se desvanece",112,"music_score_08_24","music_cover_08_24"),
        Track(9,"dream_08","Una lámpara en el abismo","La estación del último sueño","piano de fieltro, cinta suave y acordes suspendidos",128,"music_score_09_24","music_cover_09_24"),
        Track(10,"dream_09","La partida sin contrincante","La llanura de los reyes dormidos","marimba apagada, madera y respuestas desiguales",120,"music_score_10_24","music_cover_10_24"),
        Track(11,"dream_10","Porcelana que llora","El valle de las cúpulas de agua","piano acuoso, ecos asimétricos y armónicos líquidos",144,"music_score_11_24","music_cover_11_24"),
        Track(12,"dream_11","Habitaciones a la deriva","El hotel de los horizontes","cristal suave, resonancias y voces lejanas",136,"music_score_12_24","music_cover_12_24"),
        Track(13,"dream_12","La curva que nadie recuerda","La carretera donde caen estrellas","guitarra de nylon, fieltro y recuerdos desenfocados",116,"music_score_13_24","music_cover_13_24"),
        Track(14,"dream_13","Lágrimas que sostienen el cielo","El parque de las lágrimas suspendidas","coro sin palabras, campanas lejanas y respiración armónica",132,"music_score_14_24","music_cover_14_24"),
        Track(15,"dream_14","Órbitas de infancia","El tobogán de los planetas","caja de música amortiguada, ecos y cielo abierto",112,"music_score_15_24","music_cover_15_24"),
        Track(16,"dream_15","El recreo después del fin","La ciudad del último recreo","guitarra de nylon, fieltro y recuerdos desenfocados",128,"music_score_16_24","music_cover_16_24"),
        Track(17,"dark_01","Sonríe cuando no miras","El reino de las lunas dormidas","órgano cálido, tonos graves y intervalos inciertos",120,"music_score_17_24","music_cover_17_24"),
        Track(18,"dark_02","Flores para un trono vacío","El jardín de las coronas vacías","cuerdas lentas, armónicos oscuros y campanas remotas",144,"music_score_18_24","music_cover_18_24"),
        Track(19,"pocket_laundry","La ropa de otra vida","Lavandería entre nubes","marimba apagada, madera y respuestas desiguales",136,"music_score_19_24","music_cover_19_24"),
        Track(20,"pocket_train","El último vagón sumergido","El tren bajo el agua","teclado de cinta, reversos y un pulso que se desvanece",116,"music_score_20_24","music_cover_20_24"),
        Track(21,"pocket_dawn","Las seis y nunca más","El amanecer que no termina","arpa de nylon, aire y notas que quedan suspendidas",132,"music_score_21_24","music_cover_21_24"),
        Track(22,"pocket_tower","El horizonte tenía una escalera","La torre que viste desde lejos","órgano cálido, tonos graves y intervalos inciertos",112,"music_score_22_24","music_cover_22_24"),
        Track(23,"pocket_cloudbed","El peso azul del sueño","Una cama al borde del universo","coro sin palabras, campanas lejanas y respiración armónica",128,"music_score_23_24","music_cover_23_24"),
        Track(24,"pocket_refuge","También pusieron tu taza","La habitación que te espera","piano de fieltro, cinta suave y acordes suspendidos",120,"music_score_24_24","music_cover_24_24"),
        Track(25,"photo_house","La casa antes de tu llegada","Fotografía: la casa sin nadie","guitarra de nylon, fieltro y recuerdos desenfocados",144,"music_score_25_24","music_cover_25_24"),
        Track(26,"photo_sea","Una marea detenida en papel","Fotografía: el mar inmóvil","piano acuoso, ecos asimétricos y armónicos líquidos",136,"music_score_26_24","music_cover_26_24"),
        Track(27,"photo_window","El cielo detrás del cristal","Fotografía: las ventanas de ayer","cristal suave, resonancias y voces lejanas",116,"music_score_27_24","music_cover_27_24"),
        Track(28,"photo_planet","Una órbita en el álbum","Fotografía: el planeta detenido","caja de música amortiguada, ecos y cielo abierto",132,"music_score_28_24","music_cover_28_24"),
        Track(29,"pocket_letter","Dirección: nadie, nunca","La casa del destinatario ausente","flauta de aire, graves aterciopelados y silencios amplios",112,"music_score_29_24","music_cover_29_24"),
        Track(30,"pocket_gravity","El techo aprende tus pasos","El suelo que se volvió cielo","cuerdas lentas, armónicos oscuros y campanas remotas",128,"music_score_30_24","music_cover_30_24"),
        Track(31,"echo_01","Calles que se doblan al dormir","El barrio que se inclinó","teclado de cinta, reversos y un pulso que se desvanece",120,"music_score_31_24","music_cover_31_24"),
        Track(32,"echo_02","La película que mira la Tierra","El cine sobre la Tierra","órgano cálido, tonos graves y intervalos inciertos",144,"music_score_32_24","music_cover_32_24"),
        Track(33,"echo_03","Duchas para un valle vacío","Las duchas del valle infinito","piano acuoso, ecos asimétricos y armónicos líquidos",136,"music_score_33_24","music_cover_33_24"),
        Track(34,"echo_04","El reflejo llegó primero","La casa reflejada entre nubes","arpa de nylon, aire y notas que quedan suspendidas",116,"music_score_34_24","music_cover_34_24"),
        Track(35,"echo_05","Los hongos sueñan bajo el canal","El canal de los hongos dormidos","marimba apagada, madera y respuestas desiguales",132,"music_score_35_24","music_cover_35_24"),
        Track(36,"echo_06","Una nube ocupa todo el día","La colina de la nube inmensa","coro sin palabras, campanas lejanas y respiración armónica",112,"music_score_36_24","music_cover_36_24"),
        Track(37,"echo_07","Nadie viene a repostar","La última gasolinera del atardecer","guitarra de nylon, fieltro y recuerdos desenfocados",128,"music_score_37_24","music_cover_37_24"),
        Track(38,"echo_08","Sombras que eligieron otro color","El barrio de las sombras de colores","teclado de cinta, reversos y un pulso que se desvanece",120,"music_score_38_24","music_cover_38_24"),
        Track(39,"echo_09","Reservamos una silla para ti","El pasillo de las sillas vacías","piano de fieltro, cinta suave y acordes suspendidos",144,"music_score_39_24","music_cover_39_24"),
        Track(40,"echo_10","Entre los pisos falta un nombre","El edificio de los pisos sin nadie","cuerdas lentas, armónicos oscuros y campanas remotas",136,"music_score_40_24","music_cover_40_24"),
        Track(41,"echo_11","El archivo de las nubes","La oficina dentro de las nubes","caja de música amortiguada, ecos y cielo abierto",116,"music_score_41_24","music_cover_41_24"),
        Track(42,"preview_eyes","El campo sabe que estás aquí","Vista previa: la pradera que te mira","coro sin palabras, campanas lejanas y respiración armónica",132,"music_score_42_24","music_cover_42_24"),
        Track(43,"dream_rose_island","La casa rosa al final del aire","La casa rosa sobre el océano","arpa de nylon, aire y notas que quedan suspendidas",112,"music_score_43_24","music_cover_43_24"),
        Track(44,"backrooms_01","Cuarenta y nueve habitaciones despiertas","Backrooms: las luces que no descansan","órgano cálido, tonos graves y intervalos inciertos",128,"music_score_44_24","music_cover_44_24"),
        Track(45,"dream_sky_openings","Donde el cielo dejó una abertura","Las aberturas del cielo","cristal suave, resonancias y voces lejanas",120,"music_score_45_24","music_cover_45_24"),
        Track(46,"dream_cloud_castle","Un castillo en el aliento","Los corredores del castillo de nubes","coro sin palabras, campanas lejanas y respiración armónica",144,"music_score_46_24","music_cover_46_24"),
        Track(47,"dream_flower_city","El tren cruza las flores","La ciudad al otro lado de las flores","marimba apagada, madera y respuestas desiguales",136,"music_score_47_24","music_cover_47_24"),
        Track(48,"dream_grass_fissures","Un puente entre dos silencios","La pradera de las grietas","flauta de aire, graves aterciopelados y silencios amplios",116,"music_score_48_24","music_cover_48_24"),
        Track(49,"pocket_call_house","La llamada venía de adentro","La casa del teléfono desconectado","piano de fieltro, cinta suave y acordes suspendidos",132,"music_score_49_24","music_cover_49_24"),
        Track(50,"dark_03","La nieve recuerda su sonrisa","El pueblo de la luna escarlata","armonías lentas, respiración y ecos inquietantes",128,"music_score_50_27","music_cover_50_27"),
        Track(51,"dark_04","Las torres no cierran los ojos","El castillo de la sonrisa pálida","armonías lentas, respiración y ecos inquietantes",144,"music_score_51_27","music_cover_51_27"),
        Track(52,"dream_sanctuary_clouds","Alguien descansa sobre el cielo","El santuario del ojo entre nubes","armonías lentas, respiración y ecos inquietantes",136,"music_score_52_27","music_cover_52_27")
    )
    private val byWorld=tracks.associateBy{it.world}
    fun track(world:String)=byWorld[world]
}
