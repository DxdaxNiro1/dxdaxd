plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dreamcore.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dreamcore.game"
        minSdk = 21
        targetSdk = 34
        versionCode = 24
        versionName = "2.4"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes {
        release { isMinifyEnabled = false }
    }
}
