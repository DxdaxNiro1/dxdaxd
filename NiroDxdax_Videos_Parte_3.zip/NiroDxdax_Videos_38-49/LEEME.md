# NiroDxdax · DreamCore · Videos musicales

Este paquete contiene **12 videos MP4** y sus portadas con **NiroDxdax** como marca de agua visible. Cada video combina la portada ilustrada de su mapa con la canción completa correspondiente.

1. Descarga el ZIP y extrae todo su contenido.
2. Abre `VER_VIDEOS.html` para elegir una canción, o reproduce cualquier archivo de `Videos`.
3. Para YouTube, selecciona el MP4 al subir un video. Puedes usar el JPG de `Portadas` como miniatura.

Formato: 1920 × 1080, horizontal 16:9, 24 FPS, H.264 y AAC estéreo a 160 kb/s. Las imágenes permanecen fijas durante la canción. La resolución de exportación es 1080p; las portadas originales se adaptan sin recortar títulos. El álbum fue creado con asistencia de IA.

Cada ZIP es independiente y puede extraerse por separado. Los nombres de archivos son compatibles con Windows. `MANIFIESTO.json` identifica cada pareja y contiene las sumas SHA-256 de los MP4. Las portadas representan los mapas mediante ilustraciones; los videos no son grabaciones de una partida.

## Canciones incluidas

- 38. **Sombras que eligieron otro color** — El barrio de las sombras de colores (2:00)
- 39. **Reservamos una silla para ti** — El pasillo de las sillas vacías (2:24)
- 40. **Entre los pisos falta un nombre** — El edificio de los pisos sin nadie (2:16)
- 41. **El archivo de las nubes** — La oficina dentro de las nubes (1:56)
- 42. **El campo sabe que estás aquí** — Vista previa: la pradera que te mira (2:12)
- 43. **La casa rosa al final del aire** — La casa rosa sobre el océano (1:52)
- 44. **Cuarenta y nueve habitaciones despiertas** — Backrooms: las luces que no descansan (2:08)
- 45. **Donde el cielo dejó una abertura** — Las aberturas del cielo (2:00)
- 46. **Un castillo en el aliento** — Los corredores del castillo de nubes (2:24)
- 47. **El tren cruza las flores** — La ciudad al otro lado de las flores (2:16)
- 48. **Un puente entre dos silencios** — La pradera de las grietas (1:56)
- 49. **La llamada venía de adentro** — La casa del teléfono desconectado (2:12)
