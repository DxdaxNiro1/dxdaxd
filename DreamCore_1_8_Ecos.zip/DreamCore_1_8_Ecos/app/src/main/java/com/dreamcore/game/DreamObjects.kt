package com.dreamcore.game

import kotlin.math.*

object DreamObjects {
    data class Item(val key:String,val x:Float,val z:Float,val kind:String)
    data class Result(val text:String,val sound:String="chime",val pocket:String?=null,val warp:DreamJourney.Point?=null)
    private val cache=HashMap<String,List<Item>>()
    fun items(id:String):List<Item> = cache.getOrPut(id){when(id) {
        DreamWorlds.MEADOW->listOf(Item("lamp:meadow",-40f,-43f,"lamp"),Item("phone:meadow",35f,-244f,"phone"),Item("street:garden",-150f,-289f,"street"))
        DreamWorlds.HOUSE_MEADOW->listOf(Item("drawer:house",-5f,-92f,"drawer"))
        DreamExpansion.CLOUD_HOTEL->listOf(Item("radio:hotel",12f,-100f,"radio"),Item("phone:hotel",0f,-342f,"phone"),Item("door:hotel",-12f,-175f,"door"))
        DreamExpansion.TUNNELS->listOf(Item("symbol:OJO",-8f,-100f,"symbol"))
        DreamWorlds.GARDEN->listOf(Item("symbol:ESPIRAL",8f,-170f,"symbol"),Item("door:dawn",-12f,-390f,"door"))
        DreamExpansion.CHESS->listOf(Item("symbol:CASA",9f,-290f,"symbol"))
        DreamExpansion.ROAD->listOf(Item("symbol:SOL",9f,-340f,"symbol"))
        DreamWorlds.AQUARIUM->listOf(Item("door:train",12f,-245f,"door"))
        DreamWaterpark.ID->listOf(Item("phone:park",DreamWaterpark.centre(-120f)+9f,-124f,"phone"))
        DreamWorlds.HOUSE_CRATER->listOf(Item("choice:awaken",-5f,-244f,"choice"),Item("choice:stay",5f,-244f,"choice"))
        DreamPocket.LAUNDRY->listOf(Item("washer",4f,-12f,"radio"))
        DreamPocket.TRAIN->listOf(Item("radio:train",1.4f,-80f,"radio"))
        DreamPocket.DAWN->listOf(Item("drawer:dawn",4f,-20f,"drawer"))
        else->emptyList()
    }}
    fun nearest(id:String,x:Float,z:Float,feet:Float):Item?=items(id).filter {
        hypot(it.x-x,it.z-z)<2.5f && abs(feet-DreamJourney.surface(id,it.x,it.z))<2.4f
    }.minByOrNull{hypot(it.x-x,it.z-z)}
    fun label(item:Item,story:DreamChronicle)=when(item.kind) {
        "lamp"->if(item.key in story.flags)"Apagar lámpara" else "Encender lámpara"
        "phone"->"Contestar el teléfono"
        "drawer"->if(item.key in story.flags)"Examinar el cajón abierto" else "Abrir el cajón"
        "radio"->if(item.key in story.flags)"Apagar" else if(item.key=="washer")"Encender lavadora" else "Escuchar la radio"
        "symbol"->"Leer el símbolo"
        "street"->"Seguir la calle que antes no estaba"
        "choice"->if(item.key.endsWith("awaken"))"Devolver el billete · despertar" else "Guardar el billete · permanecer"
        else->"Abrir la puerta"
    }
    fun use(item:Item,story:DreamChronicle):Result=when(item.kind) {
        "lamp"->{val on=story.toggle(item.key);Result(if(on)"La lámpara se enciende. En otra casa, una ventana también responde." else "Apagas la lámpara. La otra casa recuerda la oscuridad.")}
        "phone"->Result(story.answer(item.key),"tone"+((story.calls.size-1).coerceIn(0,3)))
        "drawer"->{story.flags.add(item.key);story.flags.add("key:blue");Result("El cajón guarda una llave azul y una nota: responde, recuerda y devuelve el billete.","tone1")}
        "radio"->{val on=story.toggle(item.key);Result(if(on)"Una melodía incompleta llena el silencio." else "La habitación vuelve a quedarse vacía.",if(on)"tone2" else "chime")}
        "symbol"->{val glyph=item.key.substringAfter(':');story.symbols.add(glyph);Result("$glyph · ${story.symbols.size}/4. Las cuatro notas pertenecen a la misma melodía.","tone"+listOf("OJO","ESPIRAL","CASA","SOL").indexOf(glyph).coerceAtLeast(0))}
        "street"->Result("La calle termina ahora en un jardín. El camino de vuelta sigue abierto.",warp=if(story.layout(DreamWorlds.MEADOW)==0)DreamJourney.Point(-172f,-320f)else DreamJourney.Point(-210f,-390f))
        "choice"->{story.choose(item.key.endsWith("awaken"));Result(if(item.key.endsWith("awaken"))"Dejas el billete. Si recuerdas la melodía, la última puerta puede despertarte." else "Guardas el billete. Algo en el sueño te prepara un sitio.")}
        else->when(item.key) {
            "door:train"->Result("La puerta abre al interior de un tren. El agua queda al otro lado del cristal.",pocket=DreamPocket.TRAIN)
            "door:dawn"->Result("El amanecer sigue esperando detrás de la puerta.",pocket=DreamPocket.DAWN)
            else->Result("La puerta reconoce lo que dejaste encendido.",pocket=if("radio:hotel" in story.flags && "key:blue" in story.flags)DreamPocket.DAWN else DreamPocket.LAUNDRY)
        }
    }
    fun blocked(id:String,x:Float,z:Float)=items(id).any {
        it.kind!="door" && it.kind!="street" && abs(x-it.x)<.82f && abs(z-(it.z-1.5f))<.70f
    }
    fun lamp(id:String)=if(id==DreamWorlds.MEADOW)DreamJourney.Point(-40f,-44.5f)else DreamJourney.Point(-6f,-92f)
    fun radioNear(id:String,x:Float,z:Float,story:DreamChronicle)=items(id).any{it.kind=="radio" && it.key in story.flags && hypot(x-it.x,z-it.z)<16f}
    fun geometry(id:String,story:DreamChronicle):DreamWorlds.Scene {
        val b=DreamMesh();val cream=floatArrayOf(.78f,.76f,.69f);val wood=floatArrayOf(.50f,.36f,.27f)
        if(id==DreamWorlds.STATION && story.flags.any{it.startsWith("ending:")}) {
            val awake="ending:DESPERTAR" in story.flags;val stay="ending:PERMANECER" in story.flags
            val tint=if(awake)floatArrayOf(.95f,.77f,.48f)else if(stay)floatArrayOf(.30f,.47f,.76f)else floatArrayOf(.68f,.60f,.76f)
            for(i in 0..11){val a=i*PI.toFloat()/6f;b.ellipsoid(15f*cos(a),5f+2f*sin(a),-3f+15f*sin(a),.25f,.25f,.25f,tint,6,9,36f)}
            if(awake)for(s in floatArrayOf(-1f,1f))b.box(s*12f,6f,-24f,4f,6f,.12f,tint,34f)
            if(stay)for(s in floatArrayOf(-1f,1f))b.box(s*13f,3f,-25f,3f,3f,.13f,tint,43f)
        }
        if(id==DreamWorlds.MEADOW) {
            for((x,z)in listOf(-172f to -320f,-210f to -390f)) {
                for(i in 0..7){val a=i*PI.toFloat()*.25f;b.ellipsoid(x+10f*cos(a),DreamJourney.surface(id,x,z)+.9f,z+10f*sin(a),1.4f,.9f,1.4f,floatArrayOf(.38f,.48f,.39f),5,8,4f)}
                b.box(x,DreamJourney.surface(id,x,z)+.8f,z-4f,2.1f,.15f,.6f,cream,43f)
            }
        }
        for(o in items(id)) {
            val y=DreamJourney.surface(id,o.x,o.z);val z=o.z-1.5f
            when(o.kind) {
                "street"->{for(s in floatArrayOf(-1f,1f))b.box(o.x+s*2f,y+2f,z,.13f,2f,.15f,cream,26f)}
                "door"->{b.box(o.x,y+1.6f,z,1.1f,1.6f,.07f,cream,34f);for(s in floatArrayOf(-1f,1f))b.box(o.x+s*1.25f,y+1.7f,z,.1f,1.7f,.13f,wood,43f)}
                "lamp"->{b.box(o.x,y+1.3f,z,.08f,1.3f,.08f,wood,40f);b.ellipsoid(o.x,y+2.7f,z,.5f,.35f,.5f,cream,8,12,46f)}
                "symbol"->{b.box(o.x,y+1.6f,z,.75f,1.2f,.15f,wood,43f);b.ring(o.x,y+1.8f,z+.17f,.5f,.08f,cream);b.box(o.x,y+1.8f,z+.20f,.06f,.34f,.03f,cream,24f)}
                else->{
                    b.box(o.x,y+.9f,z,.48f,.9f,.42f,wood,43f)
                    b.box(o.x,y+1.8f,z,.68f,.08f,.56f,cream,26f)
                    val k=when(o.kind){"drawer"->47f;"radio"->48f;else->25f}
                    b.box(o.x,y+2.15f,z,.48f,.26f,.34f,if(o.kind=="phone")floatArrayOf(.26f,.29f,.29f)else wood,k)
                    if(o.kind=="phone")b.box(o.x,y+2.48f,z,.62f,.10f,.14f,wood,40f)
                }
            }
        }
        return b.finish()
    }
}
