# NiroDxdax · DreamCore · Videos musicales

Este paquete contiene **18 videos MP4** y sus portadas con **NiroDxdax** como marca de agua visible. Cada video combina la portada ilustrada de su mapa con la canción completa correspondiente.

1. Descarga el ZIP y extrae todo su contenido.
2. Abre `VER_VIDEOS.html` para elegir una canción, o reproduce cualquier archivo de `Videos`.
3. Para YouTube, selecciona el MP4 al subir un video. Puedes usar el JPG de `Portadas` como miniatura.

Formato: 1920 × 1080, horizontal 16:9, 24 FPS, H.264 y AAC estéreo a 160 kb/s. Las imágenes permanecen fijas durante la canción. La resolución de exportación es 1080p; las portadas originales se adaptan sin recortar títulos. El álbum fue creado con asistencia de IA.

Cada ZIP es independiente y puede extraerse por separado. Los nombres de archivos son compatibles con Windows. `MANIFIESTO.json` identifica cada pareja y contiene las sumas SHA-256 de los MP4. Las portadas representan los mapas mediante ilustraciones; los videos no son grabaciones de una partida.

## Canciones incluidas

- 01. **Antes de recordar** — Inicio (1:52)
- 02. **Cinco puertas al atardecer** — El Umbral: Dreamcore y Dark Fantasy (2:08)
- 03. **El agua conserva las voces** — Piscinas del recuerdo (2:00)
- 04. **Casas que caen despacio** — El abismo de las casas perdidas (2:24)
- 05. **La lluvia olvidó el suelo** — Los jardines de cristal dormido (2:16)
- 06. **Alguien dejó la luz** — El pueblo de las ventanas despiertas (1:56)
- 07. **Mareas sobre las ventanas** — El mar dentro del cielo (2:12)
- 08. **La puerta del fondo respira** — La casa que recuerda otra puerta (1:52)
- 09. **Una lámpara en el abismo** — La estación del último sueño (2:08)
- 10. **La partida sin contrincante** — La llanura de los reyes dormidos (2:00)
- 11. **Porcelana que llora** — El valle de las cúpulas de agua (2:24)
- 12. **Habitaciones a la deriva** — El hotel de los horizontes (2:16)
- 13. **La curva que nadie recuerda** — La carretera donde caen estrellas (1:56)
- 14. **Lágrimas que sostienen el cielo** — El parque de las lágrimas suspendidas (2:12)
- 15. **Órbitas de infancia** — El tobogán de los planetas (1:52)
- 16. **El recreo después del fin** — La ciudad del último recreo (2:08)
- 17. **Sonríe cuando no miras** — El reino de las lunas dormidas (2:00)
- 18. **Flores para un trono vacío** — El jardín de las coronas vacías (2:24)
